import React, { useState } from "react";
import axios from "axios";

const AddUser = () => {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    designation: "",
    email: "",
    mobile: "",
    password: "",
    role: "subuser",
    supervisor: "",
    status: "active",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "http://localhost:8080/api/users",
        formData
      );
      console.log("User added:", response.data);
      setFormData({
        firstName: "",
        lastName: "",
        designation: "",
        email: "",
        mobile: "",
        password: "",
        role: "subuser",
        supervisor: "",
        status: "active",
      });
    } catch (error) {
      console.error("Error adding user:", error);
    }
  };

  return (
    <form className="add-user-form" onSubmit={handleSubmit}>
      <input
        className="add-user-input"
        type="text"
        name="firstName"
        value={formData.firstName}
        onChange={handleChange}
        placeholder="First Name"
        required
      />
      <input
        className="add-user-input"
        type="text"
        name="lastName"
        value={formData.lastName}
        onChange={handleChange}
        placeholder="Last Name"
        required
      />
      <input
        className="add-user-input"
        type="text"
        name="designation"
        value={formData.designation}
        onChange={handleChange}
        placeholder="Designation"
        required
      />
      <input
        className="add-user-input"
        type="email"
        name="email"
        value={formData.email}
        onChange={handleChange}
        placeholder="Email"
        required
      />
      <input
        className="add-user-input"
        type="text"
        name="mobile"
        value={formData.mobile}
        onChange={handleChange}
        placeholder="Mobile"
        required
      />
      <input
        className="add-user-input"
        type="password"
        name="password"
        value={formData.password}
        onChange={handleChange}
        placeholder="Password"
        required
      />
      <select
        className="add-user-select"
        name="role"
        value={formData.role}
        onChange={handleChange}
      >
        <option value="subuser">Subuser</option>
        <option value="supervisor">Supervisor</option>
        <option value="admin">Admin</option>
      </select>
      <input
        className="add-user-input"
        type="text"
        name="supervisor"
        value={formData.supervisor}
        onChange={handleChange}
        placeholder="Supervisor ID (if any)"
      />
      <select
        className="add-user-select"
        name="status"
        value={formData.status}
        onChange={handleChange}
      >
        <option value="active">Active</option>
        <option value="inactive">Inactive</option>
      </select>
      <button className="add-user-button" type="submit">
        Add New User
      </button>
    </form>
  );
};

export default AddUser;
