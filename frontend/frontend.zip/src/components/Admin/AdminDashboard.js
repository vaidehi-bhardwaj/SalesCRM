import React from 'react'
import Content from '../Home/ContentSection';

const AdminDashboard = () => {
  return (
    <div>
      <Content />
      <h1>AdminDashboard</h1>
    </div>
  );
}

export default AdminDashboard