import React, { useState, useEffect } from "react";
import axios from "axios";

const EditUserForm = ({ user, onClose, onUserUpdated }) => {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    designation: "",
    email: "",
    mobile: "",
    role: "subuser",
    supervisor: "",
    status: "active",
  });

useEffect(() => {
  if (user) {
    console.log("User data received:", user); // Debugging line
    setFormData({ ...user });
    console.log("Form data after setting:", formData); // Additional debugging line
  }
}, [user]);


const handleChange = (e) => {
  setFormData({
    ...formData,
    [e.target.name]: e.target.value,
  });
};


const handleSubmit = async (e) => {
  e.preventDefault();

  // Create an object to store only changed fields
  const updatedFields = {};
  for (let key in formData) {
    if (formData[key] !== user[key]) {
      updatedFields[key] = formData[key];
    }
  }

  // Send only the updated fields to the server
  try {
    await axios.put(
      `http://localhost:8080/api/users/${user._id}`,
      updatedFields
    );
    onUserUpdated(); // Refresh the user table
    onClose(); // Close the modal
  } catch (error) {
    console.error("Error updating user:", error);
  }
};


  return (
    <form className="edit-user-form" onSubmit={handleSubmit}>
      <input
        className="edit-user-input"
        type="text"
        name="firstName"
        value={formData.firstName || ""} // Default to empty string if undefined
        onChange={handleChange}
        placeholder="First Name"
        required
      />
      <input
        className="edit-user-input"
        type="text"
        name="lastName"
        value={formData.lastName || ""}
        onChange={handleChange}
        placeholder="Last Name"
        required
      />
      <input
        className="edit-user-input"
        type="text"
        name="designation"
        value={formData.designation || ""}
        onChange={handleChange}
        placeholder="Designation"
        required
      />
      <input
        className="edit-user-input"
        type="email"
        name="email"
        value={formData.email || ""}
        onChange={handleChange}
        placeholder="Email"
        required
      />
      <input
        className="edit-user-input"
        type="text"
        name="mobile"
        value={formData.mobile || ""}
        onChange={handleChange}
        placeholder="Mobile"
        required
      />
      <select
        className="edit-user-select"
        name="role"
        value={formData.role || "subuser"}
        onChange={handleChange}
      >
        <option value="subuser">Subuser</option>
        <option value="supervisor">Supervisor</option>
        <option value="admin">Admin</option>
      </select>
      <input
        className="edit-user-input"
        type="text"
        name="supervisor"
        value={formData.supervisor || ""}
        onChange={handleChange}
        placeholder="Supervisor ID (if any)"
      />
      <select
        className="edit-user-select"
        name="status"
        value={formData.status || "active"}
        onChange={handleChange}
      >
        <option value="active">Active</option>
        <option value="inactive">Inactive</option>
      </select>
      <button className="edit-user-button" type="submit">
        Save Changes
      </button>
    </form>
  );
};

export default EditUserForm;
