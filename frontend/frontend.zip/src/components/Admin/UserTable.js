import React, { useState, useEffect } from "react";
import axios from "axios";
import AddUser from "./AddUser";
import EditUserForm from "./EditUserForm"; // Import the EditUserForm component
import "./UserTable.css";

const UserTable = () => {
  const [users, setUsers] = useState([]); // List of all users
  const [showModal, setShowModal] = useState(false); // Control the modal visibility
  const [editUser, setEditUser] = useState(null); // State for the user being edited

  // Fetch users from the backend
  const fetchUsers = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/users");
      setUsers(response.data);
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };

  useEffect(() => {
    fetchUsers(); // Fetch users when the component mounts
  }, []);

  // Handle editing user - fetch user details by ID
const handleEditUser = async (userId) => {
  try {
    console.log("Requesting user data for ID:", userId); // Debugging line
    const response = await axios.get(
      `http://localhost:8080/api/users/${userId}`
    );
    console.log("Fetched user data:", response.data); // Debugging line
    setEditUser(response.data);
    setShowModal(true);
  } catch (error) {
    console.error("Error fetching user details:", error);
  }
};



  // Refresh the user list after an update and close the modal
  const handleUserUpdated = () => {
    fetchUsers(); // Refresh the user list
    setShowModal(false); // Close the modal
    setEditUser(null); // Reset editUser state
  };

  return (
    <div className="user-table-container">
      <button className="user-table-button" onClick={() => setShowModal(true)}>
        Create New User
      </button>

      {showModal && (
        <div className="user-table-modal-overlay">
          <div className="user-table-modal-content">
            <button
              className="user-table-close-button"
              onClick={() => {
                setShowModal(false);
                setEditUser(null); // Reset editUser when modal is closed
              }}
            >
              &times;
            </button>
            {editUser ? (
              <EditUserForm
                user={editUser} // Pass the selected user's data to the form
                onClose={() => setShowModal(false)}
                onUserUpdated={handleUserUpdated}
              />
            ) : (
              <AddUser />
            )}
          </div>
        </div>
      )}

      <table className="user-table">
        <thead>
          <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user._id}>
              <td>{user.firstName}</td>
              <td>{user.lastName}</td>
              <td>{user.email}</td>
              <td>{user.role}</td>
              <td>{user.status}</td>
              <td>
                <button
                  className="user-table-button"
                  onClick={() => handleEditUser(user._id)}
                >
                  Edit
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default UserTable;
