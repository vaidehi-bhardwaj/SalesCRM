import React from 'react'
import Content from "../Home/ContentSection";

const SupervisorDashboard = () => {
  return (
    <div>
      <Content />
      <h1>Supervisor Dashboard</h1>
    </div>
  );
}

export default SupervisorDashboard